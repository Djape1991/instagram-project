export default [
    {
        username: 'petar_p',
        avatar: 'https://randomuser.me/api/portraits/men/35.jpg',
        opened: false
    },
    {
        username: 'marko_m',
        avatar: 'https://randomuser.me/api/portraits/women/0.jpg',
        opened: false
    },
    {
        username: 'marija_123',
        avatar: 'https://randomuser.me/api/portraits/women/53.jpg',
        opened: true
    },
]