export default [
    {
        username: 'petar_p',
        avatar: 'https://randomuser.me/api/portraits/men/35.jpg',
        url: 'https://picsum.photos/500',
        type: 'image',
        likes: '12,230',
        description: 'Is a long established fact that a reader will be distracted',
        time: '3d'
    },
    {
        username: 'marko_m',
        avatar: 'https://randomuser.me/api/portraits/women/0.jpg',
        url: 'https://st2.depositphotos.com/40853472/44728/v/600/depositphotos_447280705-stock-video-portrait-of-a-female-doctor.mp4',
        type: 'video',
        likes: '7,630',
        description: 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC',
        time: '2h'
    },
    {
        username: 'marija_123',
        avatar: 'https://randomuser.me/api/portraits/women/53.jpg',
        url: 'https://picsum.photos/510',
        type: 'image',
        likes: '2,230',
        description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
        time: '8h'
    },
]