import './App.css';
import Post from './components/Post';
import Stories from './components/Stories';
import posts from './resources/posts'

function App() {
  return (
    <div>

      <Stories/>

      {posts.map(singlePost=>{
        return <Post post={singlePost} key={singlePost.username} />
      })}
    </div>
  );
}

export default App;