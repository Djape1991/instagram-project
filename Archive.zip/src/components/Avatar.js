

function Avatar({url, username, isOpened}){
    return <div style={styles.avatarContainer}>
        <div style={{...styles.avatarImg, backgroundImage: `url(${url})`}}></div>
        <span style={styles.username}>{username}</span>
    </div>
}

const styles = {
    avatarContainer: {
        display: 'flex',
        flexFlow: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        width: 'fit-content',
        marginRight: '1rem'
    },
    avatarImg: {
        width: '60px',
        height: '60px',
        borderRadius: '100px',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
    },
    username: {
        fontSize: '.8rem',
        marginTop: '.4rem',
        color: '#393939'
    }
}

export default Avatar